#include <Eigen/Dense>

Eigen::VectorXd averageCoeffWise(std::deque<Eigen::VectorXd> anglesVector);
